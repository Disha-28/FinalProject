﻿using System.ComponentModel.DataAnnotations;

namespace Final.Models
{
    public class FindTicket
    {
        [Key]
        public int GameId { get; set; }
        public string Location { get; set; }
        public string Stadiumname { get; set; }
        [Required(ErrorMessage = "Movie name is required")]
        public string Gamename { get; set; }

        public string Slot { get; set; }
        public int charges { get; set; }

        [Required(ErrorMessage = "Date is required")]
        public DateTime? date { get; set; }
        public string GameLink { get; set; }
    }
}
