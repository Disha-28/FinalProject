﻿using Microsoft.EntityFrameworkCore;

namespace Final.Models
{
    public class StadiumDbContext : DbContext
    {

        public StadiumDbContext(DbContextOptions<StadiumDbContext> options)
          : base(options)
        {

        }

        public DbSet<Registration> Registration { get; set; }
        public DbSet<FindTicket> FindTicket { get; set; }
        public DbSet<BookTicket> BookTicket { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Registration>()
                .Property(b => b.usertype)
                .HasDefaultValue("Customer");
        }
    }
}
