﻿namespace Final.DTO
{
    public class Registrationdto
    {
        public string Token { get; set; }
    }
}
