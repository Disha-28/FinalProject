﻿using Final.Controllers;
using Final.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using Final.DTO;

namespace Final.Repository
{
    public class RegistrationRepository : IRegistrationRepository
    {
        private readonly StadiumDbContext _context;
        private readonly IConfiguration configuration;
        public RegistrationRepository(StadiumDbContext context, IConfiguration configuration)
        {
            _context = context;
  
            this.configuration = configuration;
        }
        public async Task<ActionResult<IEnumerable<Registration>>> GetRegistration()
        {

            return await _context.Registration.ToListAsync();

        }

        public async Task<ActionResult<Registration>> GetRegistration(int id)
        {
            var registration = await _context.Registration.FindAsync(id);

            return registration;
        }

        public async Task<Registrationdto> GetRegistration(string email, string password)
        {
            var userExist = _context.Registration.FirstOrDefault(t => t.email == email && EF.Functions.Collate(password, "SQL_Latin1_General_CP1_CS_AS") == password);
            if (userExist != null)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[]
                {
         new Claim(ClaimTypes.Email,userExist.email),
         new Claim("UserId",userExist.userid.ToString()),
         new Claim(ClaimTypes.Role,userExist.usertype)
     };
                var token = new JwtSecurityToken(
                    configuration["Jwt:Issuer"], 
                    configuration["Jwt:Audience"], 
                    claims, 
                    expires: DateTime.Now.AddMinutes(30), 
                    signingCredentials: credentials
                   );
                var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);
                var dto = new Registrationdto
                {
                    Token = jwtToken,
                };
                return dto;
            }
            return null;
        }
        public async Task<ActionResult<Registration>> PostRegistration(Registration registration)
        {
            _context.Registration.Add(registration);
            await _context.SaveChangesAsync();
            return registration;
        }

        public async Task<ActionResult<Registration>> PutRegistration(int id, Registration registration)
        {
            
            var user = _context.Registration.FirstOrDefault(t => t.userid == registration.userid);
            if (user != null)
            {
                user.username = registration.username;
                user.password = registration.password;
                user.email = registration.email;
                user.confirmpassword = registration.confirmpassword;

            }
            _context.SaveChanges();
            return user;
        }

        public async Task<ActionResult<Registration>> DeleteRegistration(int id)
        {
            var registration = await _context.Registration.FindAsync(id);
            _context.Registration.Remove(registration);
            await _context.SaveChangesAsync();
            return registration;
        }
        private bool RegistrationExists(int id)
        {
            return _context.Registration.Any(e => e.userid == id);
        }
    }
}
