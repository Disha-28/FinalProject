﻿using Final.Controllers;
using Final.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.IdentityModel.Tokens.Jwt;

namespace Final.Repository
{
    public class FindTicketRepository : IFindTicketRepository
    {
        private readonly StadiumDbContext _context;
        private readonly IConfiguration configuration;
        public FindTicketRepository(StadiumDbContext context, IConfiguration configuration)
        {
            _context = context;
            
            this.configuration = configuration;
        }
        public async Task<ActionResult<IEnumerable<FindTicket>>> GetFindTicket()
        {

            return await _context.FindTicket.ToListAsync();

        }

        public async Task<ActionResult<FindTicket>> GetFindTicket(int id)
        {
            var find = await _context.FindTicket.FindAsync(id);

            return find;
        }
        public async Task<ActionResult<FindTicket>> PostFindTicket(FindTicket findTicket)
        {
            _context.FindTicket.Add(findTicket);
            await _context.SaveChangesAsync();
            return findTicket;
        }


      

        public async Task<ActionResult<FindTicket>> PutFindTicket(int id, FindTicket findTicket)
        {


            var ticket = await _context.FindTicket.FindAsync(id);

            if (ticket != null)
            {
                _context.Entry(findTicket).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return findTicket;

            }

            return null;
        }

        public async Task<ActionResult<FindTicket>> DeleteFindTicket(int id)
        {
            var findTicket = await _context.FindTicket.FindAsync(id);
            _context.FindTicket.Remove(findTicket);
            await _context.SaveChangesAsync();
            return findTicket;
        }
        private bool FindTicketExists(int id)
        {
            return _context.FindTicket.Any(e => e.GameId == id);
        }

    }
}
