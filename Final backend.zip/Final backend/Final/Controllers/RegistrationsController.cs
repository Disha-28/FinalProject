﻿using Final.Models;
using Final.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;



namespace Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationsController : ControllerBase
    {
      
        private readonly IRegistrationRepository _registrationRepository;
       
        public RegistrationsController(IRegistrationRepository registrationRepository)
        {

            _registrationRepository = registrationRepository;
          

        }


       
        [HttpGet]



        public async Task<ActionResult<IEnumerable<Registration>>> GetRegistration()
        {
            return await _registrationRepository.GetRegistration();
            
        }

       
        [HttpGet("GetUserById/{id}")]
        public async Task<ActionResult<Registration>> GetRegistration(int id)
        {
            try
            {
                return await _registrationRepository.GetRegistration(id);
            }
            catch (Exception ex)
            {
              
                return NotFound();
            }
        }

        /* [HttpPost("{email}/{password}")]
         public async Task<ActionResult<Registration>> GetRegistration(string email, string password)
         {
             Hashtable err = new Hashtable();
             {
                 try
                 {
                     var authUser = await _registrationRepository.GetRegistration(email, password);
                     if (authUser != null)
                     {

                         return Ok(authUser);
                     }


                     else
                     {
                     err.Add("Status", "Error");

                     err.Add("Message", "Invalid Credentials");

                     return Ok(err);
                 }
                 }
                 catch (Exception)
                 {
                     throw;
                 }
             }
         }*/


        [HttpPost("Login/{email}/{password}")]
        //[Route("login")]
        public async Task<ActionResult<Registration>> GetRegistration(string email, string password)
        {
            Hashtable err = new Hashtable();
            {
                try
                {
                    var authUser = await _registrationRepository.GetRegistration(email, password);
                    if (authUser != null)
                    {

                        return Ok(authUser);
                    }


                    else
                    {
                        err.Add("Status", "Error");

                        err.Add("Message", "Invalid Credentials");

                        return Ok(err);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }











        [HttpPut("EditUser/{id}")]



        public async Task<IActionResult> PutRegistration(int id, Registration registration)
        {
            if (id != registration.userid)
            {
                return BadRequest();
            }

            var res = await _registrationRepository.PutRegistration(id, registration);
            if (res != null)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
       


        [HttpPost]
        public async Task<ActionResult<Registration>> PostRegistration(Registration registration)
        {
            
            await _registrationRepository.PostRegistration(registration);

            return CreatedAtAction("GetRegistration", new { id = registration.userid }, registration);
        }


       
        [HttpDelete("DeleteUser/{id}")]
        public async Task<ActionResult<Registration>> DeleteRegistration(int id)
        {
            try
            {
                return await _registrationRepository.DeleteRegistration(id);
            }
            catch (Exception ex)
            {
              
                return NotFound();
            }
         
        }

    }
}
