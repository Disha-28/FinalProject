﻿using Final.Models;
using Final.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Final.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FindTicketsController : ControllerBase
    {
        
        private readonly IFindTicketRepository _findTicketRepository;
     

        public FindTicketsController(IFindTicketRepository findTicketRepository)
        {
        
            _findTicketRepository = findTicketRepository;
         

        }

        [Authorize]
        [HttpGet]
        
        public async Task<ActionResult<IEnumerable<FindTicket>>> GetFindTicket()
        {
            return await _findTicketRepository.GetFindTicket();
           
        }

       
        [HttpGet("{id}")]
        public async Task<ActionResult<FindTicket>> GetFindTicket(int id)
        {
            var findTicket = await _findTicketRepository.GetFindTicket(id);
            

            if (findTicket == null)
            {
                return NotFound();
            }

            return findTicket;
        }

       
        [HttpPut("{id}")]
       


        public async Task<IActionResult> PutFindTicket(int id, FindTicket findTicket)
        {
            if (id != findTicket.GameId)
            {
                return BadRequest();
            }

         

            var ticket = await _findTicketRepository.PutFindTicket(id, findTicket);
            if (ticket == null)
                return NotFound();

            return Ok("Updated");


          
        }

       
        [HttpPost]


        [Authorize(Roles ="Admin")]
        public async Task<ActionResult<FindTicket>> PostFindTicket(FindTicket findTicket)
        {
            
            await _findTicketRepository.PostFindTicket(findTicket);

            return CreatedAtAction("GetFindTicket", new { id = findTicket.GameId }, findTicket);
        }

    
        [HttpDelete("{id}")]
       
        public async Task<ActionResult<FindTicket>> DeleteFindTicket(int id)
        {
           
            var findTicket = await _findTicketRepository.DeleteFindTicket(id);
            if (findTicket == null)
            {
                return NotFound();
            }

         

            return findTicket;
        }
    }
}
