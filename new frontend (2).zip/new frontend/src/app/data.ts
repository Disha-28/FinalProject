export interface Data {
    gameId: number;
    location: string;
    stadiumname: string;
    gamename:string;
    gameLink:string;
    slot:string;
    charges:number;
    date:Date;
}