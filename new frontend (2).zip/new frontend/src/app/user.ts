export interface User {
    userid: number;
    username: string;
    email: string;
    password: string;
    confirmpassword: string;
    usertype: string;
}
