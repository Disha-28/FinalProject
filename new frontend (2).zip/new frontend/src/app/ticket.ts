export interface Ticket {
    bookid: number;
    seatnum: number;
    gameId: number;
    userId: number;
    date: Date;
}
