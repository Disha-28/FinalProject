import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './login/login.component';
import { signupComponent } from './signup/signup.component';
import { CustomerDashboardComponent } from './customer-dashboard/customer-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ViewGamesComponent } from './view-games/view-games.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { UserBookingsComponent } from './user-bookings/user-bookings.component';
//import { GameIndexComponent } from './game-indexx/game-index.component';

import { GamesCreateComponent } from './games-create/games-create.component';
import { AllBookingsComponent } from './all-bookings/all-bookings.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { GameViewComponent } from './game-view/game-view.component';
import { GameIndexComponent } from './game-index/game-index.component';

const routes: Routes = [
  { path: '', component: IndexComponent },
  { path: "login", component: LoginComponent },
  { path: "signup", component: signupComponent },
  {path:"customerDashboard",component:CustomerDashboardComponent},
  {path:"adminDashboard",component:AdminDashboardComponent},
  {path:"viewGames",component:ViewGamesComponent},
  {path:"viewProfile/:userid",component:ViewProfileComponent},
  {path:"editProfile/:userid",component:EditProfileComponent},
  {path:"bookTicket",component:BookTicketComponent},
  {path:"userBookings",component:UserBookingsComponent},
  {path:"gameIndex",component:GameIndexComponent},
 // {path:"gameIndex", component: GameIndexComponent},
  {path:"gamesCreate",component:GamesCreateComponent},
  {path:"allBookings",component:AllBookingsComponent},
  {path:"contactus",component:ContactusComponent},
  {path:"aboutus",component:AboutusComponent},
  {path:"gameView/:gameId/view",component:GameViewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
